""" Quality Assessment functions
"""

from arl.data.data_models import QA

import logging
log = logging.getLogger(__name__)

        
def export_QA(qa: QA):
    """Export the accumulate QA info
        
    """
    # TODO: define and implement

    log.info("assess_quality.export_QA: not yet implemented")
