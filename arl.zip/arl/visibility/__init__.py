""" Functions for processing visibility. These operate on one or both of BlockVisibility and Visibility.

"""
